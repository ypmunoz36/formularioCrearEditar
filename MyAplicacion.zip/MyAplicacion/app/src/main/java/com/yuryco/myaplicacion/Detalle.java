package com.yuryco.myaplicacion;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

public class Detalle extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle);

        Bundle parametros  =getIntent().getExtras();

        String nombre = parametros.getString(getString(R.string.pnombre));
        String fNacimiento = parametros.getString(getString(R.string.pnacimiento));
        String telefono = parametros.getString(getString(R.string.pTelefono));
        String email =   parametros.getString(getString(R.string.pEmail));
        String descripcion =  parametros.getString(getString(R.string.pDescripcion));
        Log.i("Detalle 1", "nombre  fNacimiento"+parametros.getString(getResources().getString(R.string.pnombre)));
        Log.i("Detalle 2", "nombre  fNacimiento"+parametros.getString(getString(R.string.pnombre)));
        Log.i("Detalle", nombre + "" + fNacimiento);

        TextView tvNombre = findViewById(R.id.tvPNombre);
        TextView tvPFnacimiento = findViewById(R.id.tvPFnacimiento);
        TextView tvPTelefono = findViewById(R.id.tvPTelefono);
        TextView tvPEmail = findViewById(R.id.tvPEmail);
        TextView tvPDescripcion = findViewById(R.id.tvPDescripcion);

        tvNombre.setText(nombre);
        tvPFnacimiento.setText(fNacimiento);
        tvPTelefono.setText(telefono);
        tvPEmail.setText(email);
        tvPDescripcion.setText(descripcion);
    }
}