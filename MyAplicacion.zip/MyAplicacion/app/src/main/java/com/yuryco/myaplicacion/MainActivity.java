package com.yuryco.myaplicacion;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TextView;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    EditText etDate;
    String nombre = "";
    String telefono = "";
    String detalle = "";
    String email = "";
    String descripcion = "";
    String fechaNacimiento = "";

    DatePickerDialog.OnDateSetListener setListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etDate = findViewById(R.id.etDate);

        Calendar calendar = Calendar.getInstance();
        final int year = calendar.get(Calendar.YEAR);
        final int month = calendar.get(Calendar.MONTH);
        final int day = calendar.get(Calendar.DAY_OF_MONTH);


        etDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(
                        MainActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int month, int day) {
                        month = month + 1;
                        String date = day+"/"+month+"/"+year;
                        etDate.setText(date);
                    }
                },year,month,day);
                datePickerDialog.show();
            }
        });

        TextInputEditText  teNombre = (TextInputEditText)  findViewById(R.id.teNombre);
        nombre = teNombre.getText().toString().trim()+"";

        Log.i("MainActivity m0", "Hola mundo");
        Log.i("MainActivity m1", "nombre"+nombre);
        /*
        TextView teTelefono = findViewById(R.id.teTelefono);
        telefono = teTelefono.getText().toString();
        TextView teEmail = findViewById(R.id.teEmail);
        email = teEmail.getText().toString();
        TextView teDescripcion = findViewById(R.id.teDescripcion);
        descripcion = teDescripcion.getText().toString();
        fechaNacimiento = etDate.getText().toString();*/

    }

     public void guardarDatos(View v){
         Log.i("MainActivity m2", "nombre"+nombre);
         Intent i = new Intent(MainActivity.this, Detalle.class);
         i.putExtra(getString(R.string.pnombre),nombre);
         i.putExtra(getString(R.string.pnacimiento),fechaNacimiento);
         i.putExtra(getString(R.string.pEmail),email);
         i.putExtra(getString(R.string.pDescripcion),descripcion);
         i.putExtra(getString(R.string.pTelefono),telefono);
         startActivity(i);
     }
}